from flask import Flask, render_template, request
import pandas as pd
import numpy as np

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

app = Flask(__name__)

# -------------------------------
# Load Dataset
# -------------------------------
df =pd.read_excel("lignite_data_linearregression.xlsx")

# Convert time to hour
df["hour"] = pd.to_datetime(df["time"].astype(str)).dt.hour

# -------------------------------
# Features & Targets
# -------------------------------
X = df[["category", "hashtag_count", "views"]]
y_likes = df["likes"]
y_hour = df["hour"]

preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(drop="first"), ["category"]),
        ("num", "passthrough", ["hashtag_count", "views"])
    ]
)

likes_model = Pipeline([
    ("preprocessor", preprocessor),
    ("model", LinearRegression())
])

hour_model = Pipeline([
    ("preprocessor", preprocessor),
    ("model", LinearRegression())
])

likes_model.fit(X, y_likes)
hour_model.fit(X, y_hour)

# -------------------------------
# ROUTES
# -------------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    predicted_likes = None
    predicted_hour = None
    category = None

    if request.method == "POST":
        category = request.form["category"]
        hashtags = int(request.form["hashtags"])
        views = int(request.form["views"])

        input_data = pd.DataFrame({
            "category": [category],
            "hashtag_count": [hashtags],
            "views": [views]
        })

        predicted_likes = int(round(likes_model.predict(input_data)[0]))
        predicted_hour = int(round(hour_model.predict(input_data)[0]))

        predicted_hour = max(0, min(23, predicted_hour))

    return render_template(
        "index.html",
        predicted_likes=predicted_likes,
        predicted_hour=predicted_hour,
        category=category
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)

